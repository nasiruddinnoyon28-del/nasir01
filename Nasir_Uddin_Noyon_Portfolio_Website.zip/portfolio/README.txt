NASIR UDDIN NOYON — NEON PORTFOLIO WEBSITE

Keep index.html and the assets folder together. Open index.html in Chrome.
Before publishing, open index.html and edit the two settings near the bottom:
  EMAIL     -> your real email address
  WHATSAPP  -> your number with country code, e.g. "8801XXXXXXXXX"
The three project cards are demo placeholders; replace them with your real work.
The contact form is a front-end demo (opens email / WhatsApp). Not hosted online yet.
